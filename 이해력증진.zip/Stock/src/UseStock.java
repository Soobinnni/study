
public class UseStock {

	public static void main(String[] args) {
		
		Stock myStock=new Stock();
		System.out.println(myStock);
	}

}
